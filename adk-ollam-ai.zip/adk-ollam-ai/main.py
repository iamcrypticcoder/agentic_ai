def main():
    print("Hello from adk-ollam-ai! !!")


if __name__ == "__main__":
    main()
