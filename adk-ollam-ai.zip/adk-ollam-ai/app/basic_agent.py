# 1. Basic Agent
from google.adk.agents import Agent
from google.adk.models.lite_llm import LiteLlm

basic_agent = Agent(
    name="basic_agent",
    model=LiteLlm(
        api_base="http://localhost:11434/v1",
        model="openai/ministral-3",
        api_key="ollama"
    ),
    description="A simple agent that answers questions",
    instruction="""
    You are a helpful stock market assistant. Be concise.
    If you don't know something, just say so.
    """,
)
