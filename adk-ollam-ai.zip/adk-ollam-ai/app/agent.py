# import datetime
# from google.adk.agents import Agent
# from google.adk.agents.llm_agent import LlmAgent
# from google.adk.models.lite_llm import LiteLlm
# from litellm import api_base
# import yfinance as yf
# from google.adk.tools.google_search_tool import google_search

from . import basic_agent
from . import tool_agent
from . import stateful_agent
from . import multi_tool_agent
from . import structured_agent
from . import callback_agent

# root_agent = basic_agent.basic_agent
# root_agent = tool_agent.tool_agent
# root_agent = stateful_agent.stateful_agent
# root_agent = multi_tool_agent.multi_tool_agent
# root_agent = structured_agent.structured_agent
root_agent = callback_agent.callback_agent

# basic_agent = Agent(
#     name="basic_agent",
#     model=LiteLlm(
#         api_base="http://localhost:11434/v1",
#         model="openai/ministral-3",
#         api_key="ollama"
#     ),
#     description="A simple agent that answers questions",
#     instruction="""
#     You are a helpful stock market assistant. Be concise.
#     If you don't know something, just say so.
#     """,
# )

# root_agent = basic_agent

# def get_current_time() -> dict:
#     now = datetime.datetime.now()
#     report = {
#         f"The current time is {now.strftime('%Y-%m-%d %H:%M:%S')}"
#     }
#     return {"status": "success", "report": report}

# def get_stock_price(ticker):
#     stock = yf.Ticker(ticker)
#     price = stock.info.get('currentPrice', "Price not available")
#     return {
#         "price": price,
#         "ticker": ticker,
#     }

# time_agent = Agent(
#     name="time_agent",
#     description="A helpful agent that gets the current time",
#     instruction="You are a time assistant. You are given a time and you need to get the current time.",
#     model=LiteLlm(
#         api_base="http://localhost:11434/v1",
#         model="openai/ministral-3",
#         api_key="ollama"
#     ),
#     tools=[get_current_time],
# )

# base_agent = LlmAgent(
#     name="stock_price_agent",
#     description="A helpful agent that gets stock prices",
#     instruction=(
#         'You are a stock price assistant. You are given a ticker symbol and you need to get the current price of the stock.'
#         "Always use get_stock_price tool to get the current price of the stock. Include the ticker symbol in your response."
#     ),
#     # model=LiteLlm(model='ollama_chat/ministral-3:latest'),
#     model=LiteLlm(
#         api_base="http://localhost:11434/v1",
#         model="openai/ministral-3",
#         api_key="ollama"
#     ),
#     tools=[get_stock_price],
#     sub_agents=[time_agent]
# )

# root_agent = base_agent