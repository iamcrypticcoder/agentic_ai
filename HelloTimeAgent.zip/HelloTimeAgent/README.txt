
Please try building the project again:
Shell Script
    ./gradlew clean jar

And then run the JAR :
Shell Script
    java -jar build/libs/HelloTimeAgent-1.0-SNAPSHOT.jar




